# श्री कृष्ण इन्व्हर्टर — Remotion Reel project

Vertical 1080×1920, 30 fps, 58 sec (1740 frames). All scene text and frame timings are centralized in `src/scenes.ts`.

## Run
1. Install Node.js 20+.
2. Extract folder and open terminal in it.
3. `npm i`
4. Preview: `npx remotion studio src/index.ts`
5. Render: `npx remotion render src/index.ts SolarReel out/solar-reel.mp4`

## Voiceover
Generate Marathi narration from `VOICEOVER_MARATHI.txt` using your preferred Marathi TTS. Save as `public/voiceover.mp3`. In `src/Video.tsx`, change the optional voiceover line from `{false&&<Audio .../>}` to `{true&&<Audio .../>}`. The voiceover is one full-length track; align it to 58 seconds (or adjust scene durations in `scenes.ts`).

## Captions
The on-screen scene captions are already authored in `scenes.ts`. For word-level subtitles from your audio, generate an SRT with Whisper (e.g. Whisper Desktop / Subtitle Edit with Whisper integration), then import the SRT into CapCut or Premiere and style it. For a Remotion-native subtitle workflow, convert SRT timestamps to frame ranges and add caption sequences. Captions in this starter are scene-level, not word-by-word karaoke.

## Optional sound effects / presenter video
The whoosh/ding Audio examples are intentionally disabled so render succeeds without files. Add `public/whoosh.mp3` or `public/ding.mp3` then enable their `<Audio>` elements. Presenter SVG is replaceable; to use video, import `OffthreadVideo` and replace `<Presenter/>` with `<OffthreadVideo src={staticFile('presenter.mp4')} />`, after adding `public/presenter.mp4`.

## Notes
The public-scheme statistics, deadline and eligibility claims are supplied by the user/poster and have not been independently verified. Please verify them against official scheme/DISCOM sources before publishing. This starter avoids external image/audio assets and therefore uses a stylized vector house/panel scene.
