import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
export const Backdrop: React.FC = () => {const f=useCurrentFrame(); const rot=f*0.4; return <>
 <div style={{position:'absolute',inset:0,background:'linear-gradient(160deg,#0b1f5c 0%,#1459a8 45%,#72c9f3 100%)'}}/>
 <div style={{position:'absolute',right:-140,top:80,width:500,height:500,borderRadius:'50%',background:'radial-gradient(circle,#fff9b0 0%,#ffd21f88 35%,transparent 72%)',filter:'blur(8px)'}}/>
 <div style={{position:'absolute',right:120,top:180,width:230,height:230,borderRadius:'50%',background:'radial-gradient(circle,#fff7b0,#ff8a00)',transform:`rotate(${rot}deg)`}}/>
 <div style={{position:'absolute',bottom:0,left:-80,width:1250,height:500,background:'linear-gradient(135deg,#08245a,#07133b)',clipPath:'polygon(0 20%,100% 0,100% 100%,0 100%)'}}/>
 <div style={{position:'absolute',bottom:-40,left:0,width:1250,height:420,transform:'perspective(500px) rotateX(55deg)',transformOrigin:'bottom',background:'repeating-linear-gradient(0deg,#245da5 0 3px,transparent 3px 70px),repeating-linear-gradient(90deg,#245da5 0 3px,transparent 3px 100px)',opacity:.65}}/>
 <div style={{position:'absolute',bottom:245,right:45,width:430,height:290,background:'#f2f7ff',clipPath:'polygon(50% 0,100% 28%,100% 100%,0 100%,0 28%)',boxShadow:'0 20px 40px #0006'}}/>
 <div style={{position:'absolute',bottom:490,right:40,width:440,height:100,background:'#dbeeff',clipPath:'polygon(0 100%,50% 0,100% 100%)'}}/>
 <div style={{position:'absolute',bottom:250,right:75,width:350,height:170,background:'linear-gradient(90deg,#233b55,#5a7894)',display:'flex',gap:8,padding:12,boxSizing:'border-box'}}>{Array.from({length:4}).map((_,i)=><div key={i} style={{flex:1,background:'linear-gradient(180deg,#142d5b,#274f89)',border:'3px solid #b8d9f5'}}/>)}</div>
 <div style={{position:'absolute',bottom:585,right:75,width:350,height:160,transform:'skewY(-18deg)',background:'repeating-linear-gradient(90deg,#13376b 0 70px,#77a4d4 70px 74px),repeating-linear-gradient(0deg,#13376b 0 48px,#77a4d4 48px 52px)',border:'8px solid #d8ecff',boxShadow:'0 16px 35px #0005'}}/>
 </>};
