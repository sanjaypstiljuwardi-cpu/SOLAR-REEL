import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
export const Presenter: React.FC<{emphasis?:boolean}> = ({emphasis=false}) => {
 const f=useCurrentFrame(); const nod=Math.sin(f/12)*3; const mouth=f%18<8?7:2; const blink=(f%97<5)?0.12:1;
 return <svg width="340" height="430" viewBox="0 0 340 430" style={{overflow:'visible'}}>
  <g transform={`translate(0 ${nod})`}>
   <path d="M90 170 Q65 220 50 300 L20 380 Q65 415 105 380 L125 255 L215 255 L235 380 Q280 415 320 380 L285 300 Q270 215 240 170Z" fill="#0b1f5c" stroke="#fff" strokeWidth="5"/>
   <path d="M145 168 L170 230 L195 168" fill="#fff"/><path d="M165 230 L180 230 L174 280 L160 280Z" fill="#d71920"/>
   <rect x="110" y="55" width="120" height="135" rx="55" fill="#b9784e" stroke="#402717" strokeWidth="4"/>
   <path d="M112 105 Q95 45 145 48 Q180 18 220 60 L225 110 Q205 80 185 78 Q155 90 112 105" fill="#171717"/>
   <ellipse cx="145" cy="118" rx="10" ry="7" fill="#fff"/><ellipse cx="193" cy="118" rx="10" ry="7" fill="#fff"/><ellipse cx="145" cy="118" rx="4" ry="5" fill="#171717"/><ellipse cx="193" cy="118" rx="4" ry="5" fill="#171717"/>
   <g transform={`scale(1 ${blink})`} transform-origin="170 118"><path d="M133 113 Q145 105 156 113 M181 113 Q193 105 205 113" stroke="#222" strokeWidth="4" fill="none"/></g>
   <ellipse cx="170" cy="148" rx="16" ry={mouth} fill="#54221b"/><path d="M151 157 Q170 170 190 157" stroke="#57251b" strokeWidth="3" fill="none"/>
   <path d="M245 210 Q290 185 280 135 L275 105 Q285 75 300 95 Q310 115 305 140 L325 170 Q345 200 300 235" fill="#b9784e" stroke="#402717" strokeWidth="4"/>
   {emphasis && <path d="M290 88 L290 35 M270 45 L290 20 L310 45" stroke="#ffd21f" strokeWidth="10" strokeLinecap="round" fill="none"/>}
  </g>
 </svg>;
};
