import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/NotoSansDevanagari';
import {scenes} from './scenes';
import {Backdrop} from './components/Backdrop';
import {Presenter} from './components/Presenter';
const {fontFamily}=loadFont('normal',{weights:['400','700','900'],subsets:['devanagari','latin'],});
const C={navy:'#0b1f5c',red:'#d71920',yellow:'#ffd21f',orange:'#ff8a00',green:'#12a150',white:'#fff'};
const box=(bg:string)=>({background:bg,border:'3px solid #fff',borderRadius:28,padding:'22px 32px',boxShadow:'0 14px 35px #00163d66'});
const SceneVisual:React.FC<{scene:(typeof scenes)[number]}> = ({scene})=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig(); const p=spring({frame:f, fps, config:{damping:12,stiffness:120}}); const scale=interpolate(p,[0,1],[.7,1]); const pulse=1+Math.sin(f/5)*.025;
 const emphasis=scene.kind==='hook'||scene.kind==='warning'||scene.kind==='deadline';
 return <AbsoluteFill style={{fontFamily,justifyContent:'center',alignItems:'center',padding:'100px 72px 360px',boxSizing:'border-box',textAlign:'center'}}>
  <div style={{transform:`scale(${scale*pulse})`,width:'100%'}}>
   {scene.kind==='hook'&&<div style={{...box(C.red),fontSize:62,fontWeight:900,marginBottom:30}}>{scene.title}</div>}
   {scene.kind==='intro'&&<div style={{...box('#ffffffee'),color:C.navy,fontSize:55,fontWeight:900,marginBottom:30}}>☀️ प्रधानमंत्री<br/>सूर्यघर मोफत बिजली योजना</div>}
   {scene.kind==='stats'&&<div style={{...box(C.yellow),color:C.navy,fontSize:100,fontWeight:900,marginBottom:35}}>25.18 लाख</div>}
   {scene.kind==='target'&&<div style={{...box(C.orange),fontSize:54,fontWeight:900,marginBottom:24}}>योजना संपणार:<br/>31.03.2027</div>}
   {scene.kind==='deadline'&&<div style={{...box(C.yellow),color:C.navy,fontSize:62,fontWeight:900,marginBottom:25,borderColor:C.red}}>अंतिम मुदत:<br/>15.12.2026</div>}
   {scene.kind==='warning'&&<div style={{...box(C.red),fontSize:48,fontWeight:900,marginBottom:24}}>❌ 15.12.2026 नंतर<br/>अर्ज स्वीकारले जाणार नाहीत</div>}
   {scene.kind==='countdown'&&<div style={{...box(C.orange),fontSize:60,fontWeight:900,marginBottom:25}}>⏳ फक्त काही दिवस बाकी!</div>}
   {scene.kind==='cta'&&<div style={{...box(C.yellow),color:C.navy,fontSize:48,fontWeight:900,marginBottom:24}}>📞 आजच संपर्क करा!</div>}
   {scene.kind==='deadline'&&<div style={{fontSize:40,color:C.green,fontWeight:900,lineHeight:1.6}}>✓ National Portal वर नोंदणी<br/>✓ Valid Consent अपलोड</div>}
   {scene.kind==='stats'&&<div style={{fontSize:36,color:'#fff',fontWeight:800}}>🇮🇳 भारतातील सोलर प्रगती</div>}
   {scene.kind==='target'&&<div style={{fontSize:42,color:C.yellow,fontWeight:900}}>🎯 लक्ष्य: 1 कोटी घरे</div>}
   {scene.kind==='countdown'&&<div style={{fontSize:55,color:C.white,fontWeight:900}}>15.12.2026<br/><div style={{marginTop:18,display:'inline-block',background:'#fff',color:C.navy,borderRadius:18,padding:'10px 28px',transform:`rotateX(${Math.sin(f/4)*12}deg) translateY(${Math.sin(f/5)*4}px)`}}>२४ दिवस बाकी</div></div>}
   {scene.kind==='cta'&&<div style={{fontSize:42,color:C.white,fontWeight:900,lineHeight:1.5}}>9923444860<br/>8888498904</div>}
  </div>
  <div style={{position:'absolute',bottom:390,left:50,right:50,background:'#081a46dd',borderRadius:30,padding:28,fontSize:37,fontWeight:900,color:'#fff',lineHeight:1.5,border:'2px solid #ffffff77'}}>{scene.caption.split(/(\s+)/).map((part,i)=>{const key=scene.emphasis?.some(e=>e.split(/\s+/).some(w=>part.includes(w)));return <span key={i} style={{color:key?'#ffd21f':'#fff'}}>{part}</span>;})}</div>
  <div style={{position:'absolute',right:20,bottom:370}}><Presenter emphasis={emphasis}/></div>
 </AbsoluteFill>;
};
export const Video:React.FC=()=>{
 const f=useCurrentFrame(); const active=scenes.find(s=>f>=s.start&&f<s.start+s.duration)??scenes[scenes.length-1]; const local=f-active.start;
 const progress=f/1740; const daysRemaining=Math.max(0,Math.ceil((new Date('2026-12-15T00:00:00+05:30').getTime()-new Date('2026-11-21T00:00:00+05:30').getTime())/86400000));
 const pop=interpolate(local%75,[0,10,20,75],[0,1,1,1],{extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:C.navy,color:'#fff',fontFamily}}>
  <Backdrop/>
  {/* Optional assets are off by default so the project renders without media files. */}
  {false&&<Audio src={staticFile('voiceover.mp3')}/>}
  {false&&<Audio src={staticFile('whoosh.mp3')}/>}
  {false&&<Audio src={staticFile('ding.mp3')}/>}
  {scenes.map(s=><Sequence key={s.id} from={s.start} durationInFrames={s.duration}><SceneVisual scene={s}/></Sequence>)}
  <div style={{position:'absolute',top:42,left:42,right:42,display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:32,fontWeight:900,textShadow:'0 3px 10px #0008'}}><span>श्री कृष्ण इन्व्हर्टर</span><span style={{background:C.red,borderRadius:18,padding:'8px 18px'}}>महत्त्वाची अपडेट</span></div>
  <div style={{position:'absolute',bottom:0,left:0,right:0,height:270,background:'linear-gradient(90deg,#061845,#0b1f5c)',borderTop:'5px solid #ffd21f',padding:'25px 24px',boxSizing:'border-box',display:'flex',flexDirection:'column',justifyContent:'center',gap:12}}>
   <div style={{fontSize:36,fontWeight:900,color:C.yellow,textAlign:'center'}}>श्री कृष्ण इन्व्हर्टर सेल्स अँड सर्व्हिसेस</div>
   <div style={{fontSize:34,fontWeight:900,textAlign:'center'}}>☎ 9923444860 | 8888498904</div>
   <div style={{fontSize:28,fontWeight:800,textAlign:'center'}}>📍 संभाजी महाराज चौकाजवळ, पारोळा रोड, भडगाव</div>
  </div>
  <div style={{position:'absolute',top:0,left:0,width:`${progress*100}%`,height:12,background:C.red}}/>
 </AbsoluteFill>;
};
